module.exports = {
    "env": {
        "mocha": true,
        "commonjs": true,
        "node": true,
    },
    ...require('../../../eslint.config.js')
}
