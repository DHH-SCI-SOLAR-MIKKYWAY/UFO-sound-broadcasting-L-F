module.exports = {
    "env": {
        "mocha": true,
        "commonjs": true,
        "node": true,
        "browser": true
    },
    ...require('../../eslint.config.js')
}
