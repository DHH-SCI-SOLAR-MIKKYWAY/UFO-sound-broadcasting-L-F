Object.defineProperty(exports, "__esModule", { value: true });
exports.internallyExportedFunction = function internallyExportedFunction() {
  return true;
}
